default['lamp']['web']['document_root'] = '/var/www/default/public_html'
default['lamp']['database']['dbname'] = 'my_company'
default['lamp']['database']['admin_username'] = 'db_admin'
default['java']['oracle']['accept_oracle_download_terms'] = true
default['java']['install_flavor'] = 'oracle'
default['java']['jdk_version'] = '7'
