name             'http_deploy'
maintainer       'Granicus Inc.'
maintainer_email 'Matt Kasa <mattk@granicus.com>'
license          'agplv3'
description      'Downloads and deploys a binary package using HTTP'
long_description IO.read(File.join(File.dirname(__FILE__), 'README.md'))
version          '0.0.2'
